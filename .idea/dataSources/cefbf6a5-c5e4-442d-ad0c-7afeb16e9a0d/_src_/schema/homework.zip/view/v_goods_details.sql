CREATE VIEW `v_goods_details` AS
  SELECT
    `a`.`name`  AS `aname`,
    `a`.`price` AS `price`,
    `b`.`name`  AS `bname`,
    `c`.`name`  AS `cname`
  FROM ((`homework`.`goods` `a`
    JOIN `homework`.`goods_cates` `b` ON ((`a`.`cate_id` = `b`.`id`))) JOIN `homework`.`goods_brands` `c`
      ON ((`a`.`brand_id` = `c`.`id`)))